package code;

public enum OrderStatus {
	QUOTED, BOOKED, STARTED, // when bikes are taken out
	COMPLETE; // when bike returned by customer & deposit returned by provider
}
