package code;

public interface Deliverable {
	public void onPickup();

	public void onDropoff();
}
