package code;

public enum BikeStatus {
		AVAILABLE, CHECKED_OUT, ON_DELIVERY
}

