package code;

import java.math.BigDecimal;

public class BikeType {
	/* fields */
	private BikeProvider bikeProvider;
	private String typeName;
	private BikeCategory bikeCategory;
	private BigDecimal replacementValue;
	private BigDecimal dailyRentalPrice;
	private BigDecimal deposit;

	/* constructor */
	public BikeType(BikeProvider bikeProvider, String typeName, BikeCategory bikeCategory, BigDecimal replacementValue,
			BigDecimal dailyRentalPrice) {
		this.bikeProvider = bikeProvider;
		this.typeName = typeName;
		this.bikeCategory = bikeCategory;
		this.replacementValue = replacementValue;
		this.dailyRentalPrice = dailyRentalPrice;
		this.deposit = bikeProvider.getDepositRate().multiply(replacementValue);
	}

	/* accessors */
	public BikeProvider getBikeProvider() {
		return bikeProvider;
	}

	public String getBikeType() {
		return typeName;
	}

	public BikeCategory getBikeCategory() {
		return bikeCategory;
	}

	public BigDecimal getReplacementValue() {
		return replacementValue;
	}

	public BigDecimal getDailyRentalPrice() {
		return dailyRentalPrice;
	}
	
	public BigDecimal getDeposit() {
		return deposit;
	}

}