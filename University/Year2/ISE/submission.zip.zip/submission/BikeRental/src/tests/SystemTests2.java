package tests;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import code.Bike;
import code.BikeCategory;
import code.BikeProvider;
import code.BikeType;
import code.Customer;
import code.DateRange;
import code.DeliveryServiceFactory;
import code.EntryPoint;
import code.Location;
import code.Order;
import code.OrderStatus;

public class SystemTests2 {
	// You can add attributes here
	private BikeProvider provider1, provider2, provider3;
	private BikeType type1, type2, type3, type4, type5, type6, type7, type8;
	private Bike bike1, bike2, bike3, bike4, bike5, bike6, bike7, bike8, bike9, bike10, bike11, bike12;
	private DateRange dateRange1, dateRange2, dateRange3;
	private Location location1, location2, location3, location4;
	private EntryPoint search1, search2, search3, search4, search5;
	private BikeCategory mountain = BikeCategory.MOUNTAIN;
	private BikeCategory ebike = BikeCategory.EBIKE;
	private BikeCategory road = BikeCategory.ROAD;
	private BikeCategory hybrid = BikeCategory.HYBRID;
	private ArrayList<Order> quotes1, quotes2, quotes3, quotes4, quotes5;
	private Customer customer1, customer2, customer3;
	private Order order1, order2, order3;

	@BeforeEach
	void setUp() throws Exception {
		// Setup mock delivery service before each tests
		DeliveryServiceFactory.setupMockDeliveryService();

		// initializations of needed objects for testing
		this.location1 = new Location("EH1 1DB", "this is a street");
		this.location2 = new Location("AB10 1DB", "some street in Aberdeen");
		this.location3 = new Location("IV2 3EG", "address of Inverness castle");
		this.location4 = new Location("EH8 9LJ", "30 George Square");
		// arguments: name, location, deposit rate
		provider1 = new BikeProvider("John", location1, new BigDecimal(0.2));
		provider2 = new BikeProvider("Steve", location4, new BigDecimal(0.15));
		provider3 = new BikeProvider("Chris", location2, new BigDecimal(0.25));
		// arguments: bikeProvider, typeName, bikeCategory, replacementValue, dailyRentalPrice) {
		type1 = new BikeType(provider1, "mountain bike", mountain, new BigDecimal(100), new BigDecimal(20));
		type2 = new BikeType(provider1, "electric bike", ebike, new BigDecimal(200), new BigDecimal(30));
		type3 = new BikeType(provider1, "road bike", road, new BigDecimal(80), new BigDecimal(15));
		type4 = new BikeType(provider1, "hybrid bike", hybrid, new BigDecimal(120), new BigDecimal(25));
		type5 = new BikeType(provider2, "mountain bike", mountain, new BigDecimal(100), new BigDecimal(18));
		type6 = new BikeType(provider2, "hybrid bike", hybrid, new BigDecimal(110), new BigDecimal(25));
		type7 = new BikeType(provider2, "road bike", road, new BigDecimal(85), new BigDecimal(16));
		type8 = new BikeType(provider3, "road bike", road, new BigDecimal(90), new BigDecimal(20));
		// bikes of provider1
		bike1 = new Bike(type1);
		bike2 = new Bike(type1);
		bike3 = new Bike(type2);
		bike4 = new Bike(type3);
		bike5 = new Bike(type4);
		// bikes of provider2
		bike6 = new Bike(type5);
		bike7 = new Bike(type6);
		bike8 = new Bike(type7);
		// bikes of provider3
		bike10 = new Bike(type8);
		bike11 = new Bike(type8);
		bike12 = new Bike(type8);
		// dateRange3 overlaps with dateRange1
		this.dateRange1 = new DateRange(LocalDate.of(2019, 12, 7), LocalDate.of(2019, 12, 10));
		this.dateRange2 = new DateRange(LocalDate.of(2020, 1, 5), LocalDate.of(2020, 1, 23));
		this.dateRange3 = new DateRange(LocalDate.of(2019, 12, 8), LocalDate.of(2019, 12, 9));

		BikeCategory[] wantedBikes1 = { mountain, mountain, ebike, road };
		BikeCategory[] wantedBikes2 = { road, road, road };
		BikeCategory[] wantedBikes3 = { road, hybrid, mountain };
		this.search1 = new EntryPoint();
		this.search2 = new EntryPoint();
		this.search3 = new EntryPoint();
		this.search4 = new EntryPoint();
		this.search5 = new EntryPoint();
		// arguments: date location, BikeCategories, delivery
		quotes1 = search1.requestQuote(dateRange1, location1, new ArrayList<BikeCategory>(Arrays.asList(wantedBikes1)),
				true);
		quotes2 = search2.requestQuote(dateRange2, location2, new ArrayList<BikeCategory>(Arrays.asList(wantedBikes2)),
				false);
		quotes3 = search3.requestQuote(dateRange2, location4, new ArrayList<BikeCategory>(Arrays.asList(wantedBikes3)),
				false);
		quotes4 = search4.requestQuote(dateRange1, location3, new ArrayList<BikeCategory>(Arrays.asList(wantedBikes1)),
				false);

		// arguments: firstName, lastName, locations
		customer1 = new Customer("Bob", "J", location1); // Order?
		customer2 = new Customer("Thea", "D", location2);
		customer3 = new Customer("Mary", "K", location4);

	}

	@Test
	void testGetQuoteValid() {
		// check quote list exclude bikes already booked
		// quotes5 contains 1 result from provider1 for now
		BikeCategory[] wantedBikes1 = { mountain, mountain, ebike, road };
		quotes5 = search5.requestQuote(dateRange3, location4, new ArrayList<BikeCategory>(Arrays.asList(wantedBikes1)),
				false);
		// quotes5 has requested dates dateRange3 at location4, which overlaps with
		// dateRange1, therefore no available quote found when satisfying bikes are
		// reserved by quotes1
		quotes5 = search5.requestQuote(dateRange3, location4, new ArrayList<BikeCategory>(Arrays.asList(wantedBikes1)),
				false);
		assertNull(quotes5);
	}
}