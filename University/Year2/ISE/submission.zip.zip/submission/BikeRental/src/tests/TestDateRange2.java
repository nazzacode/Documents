package tests;


import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import code.DateRange;

class TestDateRange2 {
	private DateRange dateRange1;

	@BeforeEach
	void setUp() throws Exception {
		// Setup resources before each test
		this.dateRange1 = new DateRange(LocalDate.of(2019, 1, 7), LocalDate.of(2019, 1, 10));
	}
	
	@Test
	void testToYears1() {
		assertEquals(0, this.dateRange1.toYears());
	}

}