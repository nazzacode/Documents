package uk.ac.ed.inf.aqmaps.Christofides;

import java.util.*;

/** Node class for christofides algirithm */

public class Node {
    boolean isRoot;
    int id;
    ArrayList<Node> children;

    /**
     * Constructor for node class, setting chidren to null and root to false 
     * by default
     * 
     * @param id node id
     */
    public Node(int id) {
        this.id = id;
        children = null;
        isRoot = false;
    }

    public Node(int id, boolean isRoot) {
       this.id = id;
       this.children = null;
       this.isRoot = isRoot;
    }

    public int getNumber() { return id; }

    public void addChild(Node node) {
        if (children == null) {
            children = new ArrayList<Node>();
        }
        children.add(node);
    }

    /**
     * Finds the odd nodes in the array 
     * @param oddNodes
     */
    public void visitFindOddDegreeNodes(ArrayList<Integer> oddNodes) {
        if (children == null ) {
            oddNodes.add(id);
            return;
        }
        if ( isRoot && children.size() % 2 != 0) oddNodes.add(id);
        if (!isRoot && children.size() % 2 == 0) oddNodes.add(id);

        for (int i=0;i<children.size();i++) {
            ((Node)children.get(i)).visitFindOddDegreeNodes(oddNodes);
        }
    }
}