package uk.ac.ed.inf.aqmaps.AStar;

import com.esri.core.geometry.Point;

/** Class to model a complex step function, in our case it is constant */
public class StepCost implements CostFunction {

    private double droneStepSize;
    
    public StepCost(double droneStepSize) {
        this.droneStepSize = droneStepSize;
    }

    @Override
    public double computeCost(Point from, Point to) {
        return droneStepSize;
    }
}