package uk.ac.ed.inf.aqmaps;

import java.lang.Math;

import com.esri.core.geometry.*;

/**
 * Geometry utility functions
 */
public class GeometryUtils {
	
	/**
	 * Generates an Adjacency Matrix for an array of points accounting for the 
	 * shortest path round a noFly object
	 * 
	 * @param vertices input vertex points
	 * @param noFly no-go zone polygons
	 * @return
	 */
	public static double[][] generateAdjacencyMatrix(Point[] vertices,
	 Polygon[] noFly ) {
		int len = vertices.length;
		// initialise
		double[][] adjacencyMatrix = new double[len][len];	
		// Fill with distances (not passing though no-fly zones)
		for(int i=0; i<len;i++) {
			for(int j=0; j<len; j++) {
				adjacencyMatrix[i][j] = getPathDistance(vertices[i],
				 vertices[j], noFly);
			}
		}
		return adjacencyMatrix;
	}

	/** Constructs a polyline from points */
	public static Polyline pointsToPolyline(Point point1, Point point2) {
		Polyline polyline = new Polyline();
		polyline.startPath(point1.getX(), point1.getY());
		polyline.lineTo(point2.getX(), point2.getY());

		return polyline;
	}

	/** Calculates the euclidian distance between two points */
	public static double getEuclidianDistance(Point point1, Point point2 ) {
		Polyline polyline = pointsToPolyline(point1, point2);
		return polyline.calculateLength2D();
	}

	/**
	 * Gets the path distance between two point in the map taking the shortest 
	 * path round a noFly object if necessary.
	 * 
	 * @param point1 
	 * @param point2
	 * @param noFly array of no-fly polygon to route when calculating distance
	 * @return the path distance between the points accounting for noFly objects
	 */
	public static double getPathDistance( Point point1, Point point2, 
	 Polygon[] noFly) {
		Polyline line = pointsToPolyline(point1, point2);

		// initialise path distance pre obstacles
		double pathDist = getEuclidianDistance(point1, point2);

		// Simplify: noFly -> Convex Hull 
		// justification: 1 * 1D line intersection
		Polygon[] noFlyConvHulls = new Polygon[noFly.length];
		for(int i=0;i<noFly.length; i++) {
			Polygon noFlyConvHull = (Polygon) OperatorConvexHull.local().
			 execute(noFly[i], null);
			noFlyConvHulls[i] = noFlyConvHull;
		}
		
		// loop over noFly to increase pathDist where line intersects
		for (Polygon noFlyConvHull : noFlyConvHulls) {
			if (OperatorIntersects.local().execute(line, noFlyConvHull, null,
			 null)) {

				/* distance += outer path round smaller side of a polygon */

				// extend line
				Polyline extendedLine = extendLine(line);

				// split polygon into left cut and right cut
				GeometryCursor cuts = OperatorCut.local().execute(false, 
				 noFlyConvHull, extendedLine, null, null);
				Polygon leftCut  = (Polygon) cuts.next();
				if ( leftCut == null ) { continue; } 
				Polygon rightCut = (Polygon) cuts.next();

				// calculate the preimeter of each cut
				double leftCutPerimeter  = leftCut.calculateLength2D();
				double rightCutPerimeter = rightCut.calculateLength2D();
				
				// get intersection lengeth
				double intersectionLength = OperatorIntersection.local()
				 .execute(noFlyConvHull, line, null, null).calculateLength2D();
			
				// update path distance
				pathDist += Math.min(leftCutPerimeter,rightCutPerimeter)
												- intersectionLength;
			}
		}
		return pathDist;
	}

	/** 
	 * Extends input line 0.01 units in both directions
	 * 
	 * @param line input geometry.Polyline
	 * @return the extended line
	 */
	public static Polyline extendLine(Polyline line) {
		Point point1 = line.getPoint(0);
		Point point2 = line.getPoint(1);

		double gradient = (point2.getY() - point1.getY()) / (point2.getX() - point1.getX());

		double angle = Math.toDegrees(Math.atan(gradient));

		Point newPoint1 = goAngleDistance(point2, angle, 0.01);
		Point newPoint2 = goAngleDistance(point1, angle, -0.01);

		return pointsToPolyline(newPoint1, newPoint2);
	}

	/**
	 *  Calculates new point, an angle and distance from an existing point
	 *  (angle goes clockwise from positive x axis)   
	 * 
	 * @param point starting point
	 * @param angle angle to move in (clockwise from positive x-axis)
	 * @param distance distance to move
	 * @return new point moved distance at angle
	 */
	public static Point goAngleDistance(Point point, double angle, double distance) {
		double newLng = point.getX() + (distance * Math.cos(Math.toRadians(angle)));
		double newLat = point.getY() + (distance * Math.sin(Math.toRadians(angle)));
		
		return new Point(newLng, newLat);
	}

	/** Checks if the line between two points is out of bounds (main-BOUNDARIES/no-fly-zones)
	 * @param noFly shapes not to cross 
	 * @param BOUNDARIES to be entirly within
	 * @return true iff out of bounds
	 */
	public static boolean outOfBounds(Point point1, Point point2, Polygon[] noFly, Polygon BOUNDARIES) {
        Polyline moveVector = pointsToPolyline(point1, point2);

		// if out of main BOUNDAIRIRES
		if (!(OperatorIntersects.local().execute(point1, BOUNDARIES, null, null))
	   	 || !(OperatorIntersects.local().execute(point2, BOUNDARIES, null, null))) {
			return true;
		}

		// if in noFly zone
		for(Polygon building : noFly) {
			if (OperatorIntersects.local().execute(moveVector, building, null, null)) {
				return true;
			}
		}
		return false;  // in bounds
	}

	/**
	 * Calculates the nearest integer angle between 2 point from East (negative 
	 * x-axis) going anticlockwise
	 * 
	 * @return angle between two points in our new coordinate system
	 */
	public static int pointsToAngleFromEastGoingAntiCockwise(Point point1, Point point2) {
		double gradient = (point2.getY() - point1.getY()) / (point2.getX() - point1.getX());
		double angle = Math.toDegrees(Math.atan(gradient));
		// round to neaest int
		int angleEastAntiClock = (int) Math.rint(180 - angle);

		return angleEastAntiClock;
	}
}
