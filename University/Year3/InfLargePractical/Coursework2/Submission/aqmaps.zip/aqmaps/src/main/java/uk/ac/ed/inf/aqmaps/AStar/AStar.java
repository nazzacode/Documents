package uk.ac.ed.inf.aqmaps.AStar;

import java.util.*;

import com.esri.core.geometry.Polygon;
import com.esri.core.geometry.Point;

import uk.ac.ed.inf.aqmaps.GeometryUtils;

/** 
 * Class to solve a pathfinding instance between two Points using A* search
 */
public class AStar {
    private Graph graph;
    private final StepCost stepCost;
    private final HeuristicCost heuristicCost;
    private final int[] moveAngles;
    private final double stepSize;
    private final double sensorTolerance;
    private final Polygon[] noFly;
    private final Polygon BOUNDARIES;

    public AStar(Graph graph, StepCost stepCost, 
    HeuristicCost heuristicCost, Polygon[] noFly, Polygon BOUNDARIES,
     int[] moveAngles, double stepSize, double sensorTolerance) {
        this.graph = graph;
        this.stepCost = stepCost;
        this.heuristicCost = heuristicCost;
        this.moveAngles = moveAngles;
        this.stepSize = stepSize;
        this.sensorTolerance = sensorTolerance;
        this.noFly = noFly;
        this.BOUNDARIES = BOUNDARIES;
    }

    /**
     * Finds an A* omptimal route between two points given the constraints of the system 
     * 
     * @param from starting point
     * @param to end/goal point
     * @return A geometry.Point list of moves from start to goal
     */
    public List<Point> solve(Point from, Point to) {
        
        // openSet: nodes to be considered next
        Queue<RouteNode> openSet = new PriorityQueue<RouteNode>();
        Map<Point, RouteNode> allNodes = new HashMap<Point, RouteNode>();

        // Point from -> RouteNode start
        RouteNode startNode = new RouteNode(from, from, 0d, 
        heuristicCost.computeCost(from, to));
        // add startNode to openSet
        openSet.add(startNode);
        // add nodes to allNodes
        allNodes.put(from, startNode);

        while (!(openSet.isEmpty())) {
            // find node with min total cost 

            RouteNode currentNode = openSet.poll();

            // Check: if currentNode not out-of-bounds or in no-fly-zone
            // set its heuristicCost to infinity and `continue` in loop
            if (GeometryUtils.outOfBounds(currentNode.getPrevious(), 
             currentNode.getCurrent(), noFly, BOUNDARIES)) {
                 // remove connection instead?
                currentNode.setHeuristicCost(Double.POSITIVE_INFINITY);
            }

            // if reached destination (threshhold) return route
            // (note heuristicCost <= true distance)
            if (currentNode.getHeuristicCost() <= sensorTolerance) {
                // Edge case:  prevent sensorReading before first move
                if (currentNode == startNode && openSet.size() == 1) {
                    currentNode.setHeuristicCost(Double.POSITIVE_INFINITY);
                } else  {
                    // destination reached
                    // backtrack through pevious nodes to get route
                    List<Point> route = new ArrayList<Point>();
                    do {
                        // append element to front of route
                        route.add(0, currentNode.getCurrent());
                        currentNode = allNodes.get(currentNode.getPrevious());
                    } while (currentNode != startNode);

                    return route;
                }
            }

            // expand frontier on newNode
            expandGraphOn(currentNode.getCurrent()); 

            // for each node on new frontier
            Set<Point> connectingNodes = graph.getConnections(currentNode.getCurrent());
            for(Point connectingNode : connectingNodes) {
                // get RouteNode or create a new one
                RouteNode newNode = allNodes.getOrDefault(connectingNode, 
                new RouteNode(connectingNode));
                allNodes.put(connectingNode, newNode);
                
                // compute new stepCost (uniform in our case) 
                double newCost = currentNode.getRouteCost() + 
                stepCost.computeCost(currentNode.getCurrent(), connectingNode);

               // check of newNode already in graph with lower cost
                if (newCost < newNode.getRouteCost()) { 
                    // update newNode values
                    newNode.setPrevious(currentNode.getCurrent());
                    newNode.setRouteCost(newCost);
                    newNode.setHeuristicCost(heuristicCost.computeCost(
                     connectingNode, to));
                    openSet.add(newNode);
                }
            }
        }
        throw new IllegalStateException("No route found 2");
    }

    /**
     * Expands graph frontier arround `node` for each angle in `moveAngles` at
     *  distance `stepSize` 
     * @param node node to expand graph frontier from
     */
    public void expandGraphOn( Point node ) {

        // for each movement direction update graph nodes/connections
        for(int angle : this.moveAngles) {
            Point newNode = GeometryUtils.goAngleDistance(node,
             angle, this.stepSize);
            // add newNode
            this.graph.addNode(newNode);
            // add newNode to node's connections
            this.graph.addConnections(node, newNode);
            // add node to NewNodes' connections
            this.graph.addConnections(newNode, node);
        }
    }
    
}