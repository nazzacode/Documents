package uk.ac.ed.inf.aqmaps;

/** What3words (w3w) details class to hold deserialised Json representation */
public class W3wDetails {
    String country;
    Square square;
    public static class Square {
        Southwest southwest;
        public static class Southwest {
            Double lng;
            Double lat;
        }
        Northeast northeast;
        public static class Northeast {
            Double lng;
            Double lat;
        }
    }
    String nearestPlace;
    Coordinates coordinates;
    public static class Coordinates {
            Double lng;
            Double lat;
    }
    String words;
    String language;
    String map;
}
