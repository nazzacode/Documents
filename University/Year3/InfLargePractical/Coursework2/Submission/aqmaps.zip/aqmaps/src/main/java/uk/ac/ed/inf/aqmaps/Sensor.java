package uk.ac.ed.inf.aqmaps;

/** Sensor class to hold deserialised Json representation */
public class Sensor {

    private String location;
    private String battery;
    private String reading; 

    public String getLocation() {
        return location;
    }

    public String getBattery() {
        return battery;
    }

    public String getReading() {
        return reading;
    }
}
