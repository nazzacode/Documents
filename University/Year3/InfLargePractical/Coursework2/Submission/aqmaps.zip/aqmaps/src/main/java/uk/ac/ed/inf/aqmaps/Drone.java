package uk.ac.ed.inf.aqmaps;

import java.util.ArrayList;
import java.util.List;

import com.esri.core.geometry.Point;

/** 
 * Class to represent the functionality of our drone which flys round 
 * the point on our route  
 */
public class Drone {
    private final Point startPos;
    private final double stepSize;  // lng/lat degree
    private final int[] moveDirections;
    private Point position;
    private ArrayList<String> readings;

    /**
     * Constructor for drone class
     * 
     * @param startPos starting point
     * @param stepSize size of each move the drone makes
     * @param moveDirections array of integer angles the drone can move in
     */
    public Drone( Point startPos, double stepSize, int[] moveDirections ) {
        this.startPos = startPos;
        this.stepSize = stepSize;
        this.moveDirections = moveDirections;
        this.position = startPos;
        this.readings = new ArrayList<String>();
    }

    public ArrayList<String> getSensorReadings() {
        return readings;
    }

    /** 
     * Fly the drone round its daily sensor flightpath
     * 
     * @param flightpath a nested list of points to move the drone though, where
     * the last element of each makes a sensor reading
     * @return true if flightpath sucessful
     */
    public boolean fly( List<List<Point>> flightpath,
     ArrayList<Sensor> sensors) {
        for( int i=0;i<flightpath.size();i++) {            // sensor sub-path
            for(int j=0;j<flightpath.get(i).size();j++) {  // moves to sensor 

                // move our hyper-realistic drone
                Point nextPosition = flightpath.get(i).get(j);

                move(nextPosition);
            }
            if(i < 33) { makeSensorReading(sensors.get(i), i); }
        }

        System.out.println("Drone: Flightpath success. All sensors read");
        return true;
    }

    /** 
     * Makes a single move
     * 
     * @param to point to move the done to
     */
    private void move( Point to ) {
        System.out.println("Drone: brrr, moving to: " + to.toString());
        this.position = to;
    }

    /** 
     * Reads a sensor, when in range
     * 
     * @param sensor Sensor objec to read 
     * @param index index of sensor in daily route
     * @return string representation of the battery and reading
     */
    public String makeSensorReading( Sensor sensor, int index ) {
        // get reading
        String reading = sensor.getBattery() + "," + sensor.getReading();
        
        System.out.println("Drone: reading sensor " +
         index + ": (batterry,reading)"  + reading);

        readings.add(reading);

        return reading;   
    } 
}