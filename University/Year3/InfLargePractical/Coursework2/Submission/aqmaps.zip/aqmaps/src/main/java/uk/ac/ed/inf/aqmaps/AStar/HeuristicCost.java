package uk.ac.ed.inf.aqmaps.AStar;

import com.esri.core.geometry.*;
import com.esri.core.geometry.Point; 

import uk.ac.ed.inf.aqmaps.GeometryUtils;

/** Class to compute the Heuristic cost to the goal point*/
public class HeuristicCost implements CostFunction {
    private final Polygon[] noFly;

    public HeuristicCost(Polygon[] noFlPolygons) {
        this.noFly = noFlPolygons;
    }

   @Override
    public double computeCost(Point from, Point to) {

        // distance round noFly object
        return GeometryUtils.getPathDistance(from, to, noFly);
    }
}