package uk.ac.ed.inf.aqmaps.Christofides;

/**
 * Class to model and edge on our graph
 */
public class Edge implements Comparable {
    private int from;
    private int to;
    private double cost;

    /**
     * Constructs an Edge for a graph
     * 
     * @param from from node
     * @param to to node 
     * @param cost weight of edge 
     */
    public Edge(int from, int to, double cost) {
		this.from = from;
		this.to = to;
		this.cost = cost;
    }

    public int compareTo(Object edgeObj) {
      Edge edge = (Edge) edgeObj; 
      if      (this.getCost() == edge.getCost()) return  0;
      else if (this.getCost() >  edge.getCost()) return  1;
      else                                       return -1;
    }

    public int getTo() { return to; }

    public int getFrom() { return from; }

    public double getCost() { return cost; }
}
