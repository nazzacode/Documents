package uk.ac.ed.inf.aqmaps.Christofides;

import java.util.*;

/**
 * GraphNode class for christofides algorithm. Keeps track of its id, 
 * children and prviously visited nodes
 */
public class GraphNode{
    private final int id;
    private ArrayList<GraphNode> childList;
    private boolean visited;

    /**
     * Constructor for Graphnode
     * @param id integer id
     */
    public GraphNode( int id ) {
        this.id = id;
        childList = new ArrayList<GraphNode>();
        visited = false;
    }

    /* getters */
    public int getId(){ return id;}

    public boolean isVisited(){ return visited; }

    public boolean hasMoreChilds() { return childList.size() > 0; }

    public int getNumChilds(){ return childList.size(); }

    public void setVisited(){ visited = true; }

    public void setNotVisited(){ visited = false; }
    
    public void addChild(GraphNode node){
        if(!(this.getId()==node.getId()) ){
            childList.add(node);
        }
    }
    
    public void removeChild(GraphNode node){
        childList.remove(node);
    }





    public void getNextChild(int goal, Vector<Integer> path, boolean firstTime){
        // if we have reached our goal then quit
        if (this.getId()==goal && !firstTime){
            path.add(this.getId());
        } else {
            // if more paths from this node, add the node and continue along 
            // the first best of the edges, also remove the edge.
            if( childList.size()>0 ){
                GraphNode tmpNode=(GraphNode)childList.remove(0);
                tmpNode.removeChild(this); //ta bort kanten från andra hållet
                path.add(this.getId());
                tmpNode.getNextChild(goal,path,false);
            }
        }
    }
}