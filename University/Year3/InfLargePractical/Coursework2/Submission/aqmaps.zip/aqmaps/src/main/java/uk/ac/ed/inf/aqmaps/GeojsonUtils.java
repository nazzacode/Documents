package uk.ac.ed.inf.aqmaps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.mapbox.geojson.*;

/**
 * Class for geojson related utility fuctions
 * 
 * Note com.mapbox.geojson classes can used without qualification (they clash
 * with com.esri.core.geometry which usually take precedence)
 */
public class GeojsonUtils {

    /**
     * Creates geojson map of sensors & flightpath (as per Coursework spec.)
     * 
     * @param sensors list of sensors to generate map for
     * @param sensorLocations list of point location of the sensors
     * @param flightpath string representation of the calculated flightpath
     * @return geojson representation of the sensor points and flightpath, 
     * with sensors color coded (& symbolised) by air polution level/battery
     */
    public static FeatureCollection generateReadingsMap(ArrayList<Sensor> sensors,
     com.esri.core.geometry.Point[] sensorLocations, String[] flightpath) {
		// initialise list of geojson features
        List<Feature> features = new ArrayList<>();
        
        // --- 1. Sensors ---

        // initialise loopuk maps 
        // for adding color/symbols to sensors in output
        SortedMap<Integer, String> pollutionToRgb = generatePollutionToRgbMap();
        HashMap<String, String> rgbToSymbol = generateRgbToSymbolMap();

        // add sensor points
        for (int i=0;i<sensors.size();i++) {
            // create geojson sensor point
            Point sensorPoint = Point.fromLngLat(sensorLocations[i].getX(),
                                                 sensorLocations[i].getY());

            // get values from lookup maps to fill sensor Feature properties
            String rgbString;
            // if sensor battery suggests ilegitimate reading
            String battery = sensors.get(i).getBattery();  
            if (battery == "null" || battery == "NaN" 
             || Double.parseDouble(battery) < 10.0) {
                rgbString = getPolutionToRgb(-2, pollutionToRgb); 
            } else {
                rgbString = getPolutionToRgb(Double.parseDouble(
                 sensors.get(i).getReading()), pollutionToRgb);
            }
            String markerSymbol = rgbToSymbol.get(rgbString);

            JsonObject properties = new JsonObject();
            // add values to sensor properties
            properties.add("location", new Gson().toJsonTree(sensors.get(i).getLocation()));
            properties.add("rgb-string", new Gson().toJsonTree(rgbString));
            properties.add("marker-color", new Gson().toJsonTree(rgbString));
            properties.add("marker-symbol", new Gson().toJsonTree(markerSymbol));

            // construct Feature from sensor point and properties
            Feature sensorFeature = Feature.fromGeometry(sensorPoint, properties);

            // append to feature list
            features.add(sensorFeature);
        }

        // --- 2. Flightpath ---

        List<Point> flightPoints = new ArrayList<>();
        // desonstruct each flightpath move string 
        // to reconstrict a geojson line (via points)
        for (String move : flightpath) {
            if (move != null) {
                String[] moveArray = move.split(",");
                Double fromLng = Double.parseDouble(moveArray[1]);
                Double fromLat = Double.parseDouble(moveArray[2]);
                Double toLng = Double.parseDouble(moveArray[4]);
                Double toLat = Double.parseDouble(moveArray[5]);

                // if first iteration create and add starting point
                if (move == flightpath[0]) {
                    Point flighPoint = Point.fromLngLat(fromLng, fromLat);
                    flightPoints.add(flighPoint);
                }
            
                // create and add to point
                Point flighPoint = Point.fromLngLat(toLng, toLat);
                flightPoints.add(flighPoint);
            }
        }
        // convert flightpath points to geojson line
        LineString flightLine = LineString.fromLngLats(flightPoints);
        //convert flightLine to Feature
        Feature flightFeature = Feature.fromGeometry(flightLine);

        // combine flighpath with sensors features
        features.add(flightFeature);

        // --- / ---

        // convert list of features to FeatureColleciton
        FeatureCollection featureCollection = 
                                    FeatureCollection.fromFeatures(features);

        return featureCollection;
    }

    /** 
     * Initialises a pollution-value to rgb-hexcode map for colorcoding sensors
     * in the output geojson where (key, value) = (pollution-bucket-upper-bound, 
     * RGB-color-string) as specified in ilp-coursework.pdf Figure 5
     * 
     * @return treemap of pollution-bucket-upper-bound, RGB-color-string
     */
    public static final SortedMap<Integer, String> generatePollutionToRgbMap() { 
        var pollutionToRgb = new TreeMap<Integer, String>();

        pollutionToRgb.put(-1,   "#000000");
        pollutionToRgb.put(32,  "#00ff00"); 
        pollutionToRgb.put(64,  "#40ff00"); 
        pollutionToRgb.put(96,  "#80ff00"); 
        pollutionToRgb.put(128, "#c0ff00"); 
        pollutionToRgb.put(160, "#ffc000");  
        pollutionToRgb.put(192, "#ff8000"); 
        pollutionToRgb.put(224, "#ff4000"); 
        pollutionToRgb.put(256, "#ff0000"); 
    
        return pollutionToRgb;
    }

    /** 
     * Initialises rgb-hexcode to picture-symbol map for attaching symbols 
     * to points in output geojson (as specified in ilp-coursework.pdf Figure 5)
     * @return a HashMap of rgb-hexcode to picture-symobl string 
     */
    public static HashMap<String, String> generateRgbToSymbolMap() { 
        var rgbToSymbol = new HashMap<String, String>();

        rgbToSymbol.put("#000000", "cross");
        rgbToSymbol.put("#00ff00", "lighthouse"); 
        rgbToSymbol.put("#40ff00", "lighthouse"); 
        rgbToSymbol.put("#80ff00", "lighthouse"); 
        rgbToSymbol.put("#c0ff00", "lighthouse"); 
        rgbToSymbol.put("#ffc000", "danger");  
        rgbToSymbol.put("#ff8000", "danger"); 
        rgbToSymbol.put("#ff4000", "danger"); 
        rgbToSymbol.put("#ff0000", "danger"); 

        return rgbToSymbol;
    }

	/** Maps pollution concentration estimate to RGB colour bucket  */
    public static String getPolutionToRgb(double concentration, SortedMap<Integer, String> pollutionToRgb) {
        Set keySet = pollutionToRgb.entrySet();
        Iterator iter = keySet.iterator(); 
        Map.Entry mapEntry = null;
  
        // Traverse map (by increasing key values)
        while (iter.hasNext()) { 
            mapEntry = (Map.Entry) iter.next(); 
            int key = (Integer) mapEntry.getKey();
            if (concentration <= key) {
                break;
            }
        }
        String rgbString = (String) mapEntry.getValue(); 

		return rgbString;
	}
}