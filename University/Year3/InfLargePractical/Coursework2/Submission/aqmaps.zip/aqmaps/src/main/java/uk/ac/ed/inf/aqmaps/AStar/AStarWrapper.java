package uk.ac.ed.inf.aqmaps.AStar;

import java.util.*;

import com.esri.core.geometry.*;
import com.esri.core.geometry.Point;


/**
 * Class implementing the the totality of our A* search algorithm to plot a roundtrip
 *  on a set of `vertics`  by calling the AStar between every progressive pair of points
*/
public class AStarWrapper {
	

	/**
	 * Entry point to solve the A* instance 
	 * 
	 * @param vertices Point list of vertices to visit
	 * @param noFly no fly poygons the path cannt cross
	 * @param BOUNDARIES geometry.Polygon coordinate grid bounderies
	 * @param moveAngles list of integer degree angles the agent (drone) can move in 
	 * @param moveSize step size of each move
	 * @param vertexTolerance distance within which a vertex can be cosidered reached
	 * @return movement flightpath as a nested list of Points where the last element 
	 * of each list reaches a vertex
	 */
	public static List<List<Point>> solve( Point[] vertices,
	 Polygon[] noFly, Polygon BOUNDARIES, int[] moveAngles, 
	  double moveSize, double vertexTolerance ) {

		// Create list of list to store route
		// the last element of each list takes a sensor reading
		var route = new ArrayList<List<Point>>();
		
		// Initalise cost functions
		// tepCost = droneStepSize
		StepCost stepCost = new StepCost(moveSize);
		// heriristicCost = GeometryUtils.getPathDistance
		HeuristicCost heuristicCost = new HeuristicCost(noFly);

		// initalise 'from' node as starting point
		Point from = vertices[0];

		// loop over sensor poitions
		// treating each sensor as an individual A* instance
		for(int i=0;i<vertices.length-1;i++) {

			// 'to' point is next sensor
			Point to = vertices[(i+1) % vertices.length];

			/* Initialise Graph with nodes and connections */
			Set<Point> nodes = new HashSet<Point>();
			nodes.add(from);
			//nodes.add(to);
			// initiallise empty connections
			var connections = new HashMap<Integer, Set<Integer>>();
			// add 'from' node to connections
			connections.put(from.hashCode(), new HashSet<Integer>());
			// initialse graph = (nodes, edges)
			Graph graph = new Graph(nodes, connections);

			// find A* route between two nodes (sensors)
			AStar aStar = new uk.ac.ed.inf.aqmaps.AStar.AStar(graph, stepCost,
			 heuristicCost, noFly, BOUNDARIES, moveAngles, moveSize, 
			 vertexTolerance);

			System.out.println("finding route to sensor:"+ i);
			List<Point> sensorRoute = aStar.solve(from, to);

			// if first iteration append start point to front of route
			if (i==0) { sensorRoute.add(0, from); }

			// add sensorRoute to route
			route.add(sensorRoute);

			// update 'from' node to current position
			from = sensorRoute.get(sensorRoute.size() - 1);
		}
		return route;
	}
}