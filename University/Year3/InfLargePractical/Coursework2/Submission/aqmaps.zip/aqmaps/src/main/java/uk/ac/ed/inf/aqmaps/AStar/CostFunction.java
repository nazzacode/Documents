package uk.ac.ed.inf.aqmaps.AStar;

import com.esri.core.geometry.Point;

/** Abstract interface to be implemented by `StepCost` and `HeuristicCost` */
public interface CostFunction {

    /**
     * Abstract method for computing a cost function between two points
     * @param from from point
     * @param to two point
     * @return functional dependent cost between points
     */
    double computeCost(Point from, Point to);
}