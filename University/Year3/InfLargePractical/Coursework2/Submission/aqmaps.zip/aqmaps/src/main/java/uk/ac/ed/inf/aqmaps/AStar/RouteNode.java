package uk.ac.ed.inf.aqmaps.AStar;

import com.esri.core.geometry.Point;

/**
 * Class to model geographical nodes on A* route
 * kepping track of the `previous` node, `routeCost`, the cost so far & `heursticCost`,
 * the estimated to goal node
 */
public class RouteNode implements Comparable<RouteNode> {
    private final Point current;
    private Point previous;
    private double routeCost;
    private double heuristicCost;

    /**
     * Constructor for a route node setting the previousNode to null, the 
     * routeCost to infinity and the heuristicCost to infinity
     * @param current current point 
     */
    RouteNode(Point current) {
        this.current = current;
        this.previous = null;
        this.routeCost = Double.POSITIVE_INFINITY;
        this.heuristicCost = Double.POSITIVE_INFINITY;
    }

    RouteNode(Point current, Point previous, double routeCost, double heuristicCost) {
        this.current = current;
        this.previous = previous;
        this.routeCost = routeCost;
        this.heuristicCost = heuristicCost;
    }

    @Override
    public int compareTo(RouteNode other) {

        if (this.heuristicCost > other.getHeuristicCost()) { return 1; } 
        else if (this.heuristicCost < other.getHeuristicCost()) { return -1; } 
        else { return 0; }
    }

    public Point getCurrent() {
        return this.current;
    }

    public Point getPrevious() {
        return this.previous;
    }

    public double getRouteCost() {
        return this.routeCost;
    }

    public double getHeuristicCost() {
        return this.heuristicCost;
    }

    public void setPrevious(Point newPrevious) {
        this.previous = newPrevious;
    }

    public void setRouteCost(double newrouteCost) {
        this.routeCost = newrouteCost;
    }

    public void setHeuristicCost(double newheuristicCost) {
        this.heuristicCost = newheuristicCost;
    }
}