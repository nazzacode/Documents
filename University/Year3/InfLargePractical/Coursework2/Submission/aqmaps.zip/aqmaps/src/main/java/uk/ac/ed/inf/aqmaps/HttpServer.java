package uk.ac.ed.inf.aqmaps;

import java.io.*;

import java.lang.InterruptedException;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;

/**
 * HttpServer class for connecting to and accessing files from a local server
 */
public class HttpServer {
    public static final HttpClient client = HttpClient.newHttpClient();
    public final String serverUrl;

    public HttpServer( String serverUrl ) {
        this.serverUrl = serverUrl;
    }

	/**
     * Gets a file from the HTTP server
     * @param filepath filepath within the server
     * @return String of the file
     */
    public final String getFile( String filepath ) {

        HttpRequest request = HttpRequest.newBuilder().uri(URI.create(
         serverUrl + filepath)).build();

        // Connect to server & make request
        try { 
            HttpResponse<String> response = client.send(
             request, BodyHandlers.ofString());  
            // check status code
            int statusCode;
            if ((statusCode = response.statusCode()) == 200 ) {  // 200 is good
                // read in file 
                String file = response.body();

                return file;
            }
            // handle status code error 
            else {
                System.out.println( "Fatal error: Could not retrieve data from: "
                 + serverUrl + filepath + " Http status code" + response);

                System.exit(1); // Exit the application
            }

        } catch( IOException | InterruptedException e ) {
            System.out.println( e );
            System.exit(1); // Exit the application
        }
        return "";
    }
}