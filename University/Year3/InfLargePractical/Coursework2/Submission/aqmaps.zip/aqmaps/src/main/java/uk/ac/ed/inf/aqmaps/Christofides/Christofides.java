package uk.ac.ed.inf.aqmaps.Christofides;

import java.util.*;
/** 
 * Class implemeting the Christofides Algorithm on an instance of the Traveling
 *  Salesman Problem
 */
public class Christofides{


    /**
	 *  Entry point for the christofides algorithm
	 * 
	 * @param AdjMatrix sqaure adjacency matrix representing the weights 
	 * between nodes in a graph 
     * @return an integer array of the christofides near optimal tour of the 
	 * input vertices by index of original ordering
     */
	public static int[] solve(double[][] AdjMatrix){

		// calculate an mst using prims algorithm
		// mst = minimum spanning tree
		int mst[] = prim(AdjMatrix, AdjMatrix[0].length);

		// find a matching between between the nodes of odd-degree
		// (even number by the handshake lemma)
		int match[][] = greedyMatch(mst, AdjMatrix, AdjMatrix[0].length);

		// build the union of mst and match (a multigraph)
		GraphNode nodes[] = makeMuliGraph(match, mst);

		// calculate final route as an euler tour
		// possible as every vertex now has an even degree
		int route[] = makeEulerCircuit(nodes);   // removes loops

		double sum = 0;
		for (int i = 1; i < route.length; i++) {
			sum += AdjMatrix[route[i - 1]][route[i]];
		}
		sum += AdjMatrix[route[0]][route[route.length - 1]];
		System.out.println("Summan: " + sum);

		return route;
	}

	/**
	 * Builds the union of mst and (bipartite) match, which is a multi graph
	 * 
	 * @param nodes Multigraph with only even degree nodes.
	 * @return Euler circuit with shortcuts
	 */
	private static int[] makeEulerCircuit(GraphNode nodes[]) {
		LinkedList path = new LinkedList<GraphNode>();
		Vector tmpPath = new Vector<GraphNode>();
		int j = 0;

		// put the first cycle in the path, getNextChild goes deep first
		nodes[0].getNextChild(nodes[0].getId(), tmpPath, true);
		path.addAll(0, tmpPath);

		// go through all the nodes in our path, if the node has more outgoing
		// edges then check cycles for this and put the cycle in the right place
		while (j < path.size()) {

			if (nodes[((Integer) path.get(j)).intValue()].hasMoreChilds()) {
				nodes[((Integer) path.get(j)).intValue()]
						.getNextChild(nodes[((Integer) path.get(j)).intValue()].getId(), tmpPath, true);

				if (tmpPath.size() > 0) {
					// put together path and tmpPath

					for (int i = 0; i < path.size(); i++) {
						if (((Integer) path.get(i)).intValue() == ((Integer) tmpPath.elementAt(0)).intValue()) {
							path.addAll(i, tmpPath);
							break;
						}
					}
					tmpPath.clear();
				}
				j = 0;
			} else
				j++;
		}

		// find shortcuts on Euler tour
		boolean inPath[] = new boolean[nodes.length];
		int[] route = new int[nodes.length];
		j = 0;
		for (int i = 0; i < path.size(); i++) {
			if (!inPath[((Integer) path.get(i)).intValue()]) {
				route[j] = ((Integer) path.get(i)).intValue();
				j++;
				inPath[((Integer) path.get(i)).intValue()] = true;
			}
		}
		return route;
	}

	/**
	 * Builds the union of mst and match, which is a multi graph
	 * 
	 * @param match The "minimum" perfect match on the set of odd nodes.
	 * @param mst   The minimal spanning tree
	 * @return One dimensional nodes matrix representing the multi graph
	 */
	private static GraphNode[] makeMuliGraph(int[][] match, int[] mst) {
		var nodes = new GraphNode[mst.length];
		// create empty nodes
		for (int i = 0; i < mst.length; i++) {
			nodes[i] = new GraphNode(i);
		}

		// add nodes and edges from mst
		for (int i = 1; i < mst.length; i++) {
			nodes[i].addChild(nodes[mst[i]]);
			nodes[mst[i]].addChild(nodes[i]);
		}

		// add nodes and edges from match
		for (int i = 0; i < match.length; i++) {
			nodes[match[i][0]].addChild(nodes[match[i][1]]);
			nodes[match[i][1]].addChild(nodes[match[i][0]]);
		}

		return nodes;
	}

	/**
	 * Using Prim's algorithm to find the Minimal Spanning Tree.
	 * 
	 * @param AdjMatrix input weight matrix.
	 * @param dim Number of dimensions in the problem.
	 * @return The parentvector. p[i] gives the parent of node i.
	 */
	public static int[] prim(double[][] AdjMatrix, int dim) {
		var queue = new Vector<Integer>();
		for (int i = 0; i < dim; i++)
			queue.add(i);

		// Prim's algorithm
		boolean isInTree[] = new boolean[dim];
		double key[] = new double[dim]; // distance from node i and node parent[i].
		int p[] = new int[dim]; // parent

		for (int i = 0; i < dim; i++) {
			key[i] = Integer.MAX_VALUE;
		}

		key[0] = 0; // root-node
		int u = 0;

		double temp;
		Integer elem;
		do {
			isInTree[u] = true; // add node to tree
			queue.removeElement(u);
			for (int v = 0; v < dim; v++) { // can be simplified if it is not a complete graph
				if (!isInTree[v] && AdjMatrix[u][v] < key[v]) {
					p[v] = u;
					key[v] = AdjMatrix[u][v];
				}
			}

			// ExtractMin, goes through all the remaining nodes and takes the one
			// out with the shortest distance to the tree
			double mint = Double.MAX_VALUE;
			for (int i = 0; i < queue.size(); i++) {
				elem = (Integer) queue.elementAt(i);
				temp = key[elem.intValue()];
				if (temp < mint) {
					u = elem.intValue();
					mint = temp;
				}
			}
		} while (!queue.isEmpty());

		return p;
	}

	/**
	 * Finds a match between the nodes that hava odd number of edges. Not perfect
	 * but greedy, that is take the shortest distance found first. Then the next
	 * shortest of the remaining i chosen.
	 * 
	 * @param prarentVec Parentvector. p[i] gives the parent of node i.
	 * @param AdjMatrix  Weightmatrix of the complete graph.
	 * @param dim        Number of dimensions in the problem.
	 * @return Two dimensional matrix containing the pairs. Two columns where each
	 *         row represent a pair.
	 */
	public static int[][] greedyMatch(int[] prarentVec, double[][] AdjMatrix, int dim) {
		Node nodes[] = new Node[prarentVec.length];

		// create forest
		nodes[0] = new Node(0, true); //roten
		for(int i =1; i<prarentVec.length;i++) {
			nodes[i] = new Node(i,false);
		}

		// make tree from forest
		for(int i = 0; i<prarentVec.length;i++) {
			if(prarentVec[i]!=i)
				nodes[prarentVec[i]].addChild(nodes[i]);
		}

		// find odd nodes
		ArrayList oddDegreeNodes = findOddDegreeNodes(nodes[0]);
		int nOdd = oddDegreeNodes.size();

		// try to find as minimal a match as possible with a greedy method
		// sort all the edges between the odd corners
		Edge edges[][] = new Edge[nOdd][nOdd];
		for (int i=0;i<nOdd;i++) {
			for (int j=0;j<nOdd;j++) {
				if (((Integer) oddDegreeNodes.get(i)).intValue() != ((Integer) oddDegreeNodes.get(j)).intValue())
					edges[i][j] = new Edge(((Integer) oddDegreeNodes.get(i)).intValue(),
							((Integer) oddDegreeNodes.get(j)).intValue(),
							AdjMatrix[((Integer) oddDegreeNodes.get(i)).intValue()][((Integer) oddDegreeNodes.get(j))
									.intValue()]);
				else
					edges[i][j] = new Edge(((Integer) oddDegreeNodes.get(i)).intValue(),
							((Integer) oddDegreeNodes.get(j)).intValue(), Double.MAX_VALUE);
			}
			Arrays.sort(edges[i]); // sort all edges from node i
		}

		boolean matched[] = new boolean[dim];
		int match[][] = new int[(nOdd / 2)][2];

		// for each corner pick out the shortest edge
		// in the event of a collision, select the shortest of the second shortest.
		// the number of nodes with odd degrees always divisible by 2
		int k = 0;
		for (int i = 0; i < nOdd; i++) {
			for (int j = 0; j < nOdd; j++) {
				if (matched[edges[i][j].getFrom()] || matched[edges[i][j].getTo()])
					continue;
				else {
					matched[edges[i][j].getFrom()] = true;
					matched[edges[i][j].getTo()] = true;
					match[k][0] = edges[i][j].getFrom();
					match[k][1] = edges[i][j].getTo();
					k++;
				}
			}
		}
		return match;
	}

	/**
	 * Finds vertexes which have odd number of edges.
	 * 
	 * @param root root node.
	 * @return List of indices of nodes with odd number of edges.
	 */
	private static ArrayList<Integer> findOddDegreeNodes(Node root) {
		var oddNodes = new ArrayList<Integer>();
		root.visitFindOddDegreeNodes(oddNodes);

		return oddNodes;
    }
}