package uk.ac.ed.inf.aqmaps.AStar;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.esri.core.geometry.Point;

/** Graph class for A* search algorithm containing a set of `nodes` and map of `connections`  */
public class Graph {
    private Set<Point> nodes;
    private Map<Integer, Set<Integer>> connections;

    /**
     * Constructor creating a graph from nodes and connections
     * @param nodes set of nodes to add to graph
     * @param connections map node id's to set of node id's its connected to
     */
    public Graph(Set<Point> nodes, Map<Integer, Set<Integer>> connections) {
        this.nodes = nodes;
        this.connections = connections;
    }


    public Point getNode(Integer id) {

        return nodes.stream().filter(node -> node.hashCode() == id).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No node found with ID"));
    }

    public Set<Point> getConnections(Point node) {

        return connections.get(node.hashCode()).stream().map(this::getNode).collect(Collectors.toSet());
    }

    /** Adds a node to the graph */
    public void addNode(Point node) {
        this.nodes.add(node);
    }

    /**
     * Adds connection to graph
     * @param from node 1
     * @param to node 2
     */
    public void addConnections(Point from, Point to) {
        Set<Integer> nodeConnections = this.connections.getOrDefault(from.hashCode(), new HashSet<Integer>());
        nodeConnections.add(to.hashCode());
        this.connections.put(from.hashCode(), nodeConnections);
    }
}
    